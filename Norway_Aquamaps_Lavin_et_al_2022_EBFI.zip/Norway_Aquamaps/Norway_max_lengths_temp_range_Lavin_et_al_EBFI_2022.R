
# Warm and cold temperatures limit the maximum body length
# of teleost fishes across a latitudinal gradient in Norwegian waters

# Environmental Biology of Fishes
# April 2022

# Corresponding author: Charles P. Lavin
# email: charles.p.lavin@nord.no

# Script and data for:
# Calculating temperature range (Fig. 3) for:
# Spotted wolffish (Anarhichas minor), Atlantic wolffish (Anarhichas lupus),
# Cusk (Brosme brosme), Greenland halibut (Reinhardtius hippoglossoides),
# Norway redfish (Sebastes viviparus), Golden redfish (Sebastes norvegicus),
# Beaked redfish (Sebastes mentella), Capelin (Mallotus villosus),
# Daubed shanny (Leptoclinus maculatus), Polar cod (Boreogadus saida)

# Data extracted from species' AquaMaps page, under
# 'show mapping parameters' subsection -> 'cells used for 
# creating environmental envelope' -> Water Temp (degrees C) -> Bottom
# https://www.aquamaps.org/

# Spotted wolffish
spotted = read.csv("spotted.csv")
summary(spotted)
quantile(spotted$Bottom, c(0.10))
mean(spotted$Bottom)
quantile(spotted$Bottom, c(0.90))
summary(spotted$Bottom)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# -1.190   1.655   3.005   3.269   3.875  11.500 


# Atlantic wolffish
wolffish = read.csv("wolffish.csv")
summary(wolffish)
quantile(wolffish$Bottom, c(0.10))
mean(wolffish$Bottom)
quantile(wolffish$Bottom, c(0.90))
summary(wolffish$Bottom)
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# -1.130   3.020   5.840   5.765   8.412  14.880 


# Cusk
cusk = read.csv("cusk.csv")
summary(cusk)
quantile(cusk$Bottom, c(0.10))
mean(cusk$Bottom)
quantile(cusk$Bottom, c(0.90))
summary(cusk$Bottom)
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# -1.010   4.987   7.625   7.212   9.400  17.120


# Greenland halibut
halibut = read.csv("halibut.csv")
summary(halibut)
quantile(halibut$Bottom, c(0.10))
mean(halibut$Bottom)
quantile(halibut$Bottom, c(0.90))
summary(halibut$Bottom)
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# -1.330   1.180   2.780   2.921   3.990  17.160


# Norway redfish
norway = read.csv("norway.csv")
summary(norway)
quantile(norway$Bottom, c(0.10))
mean(norway$Bottom)
quantile(norway$Bottom, c(0.90))
summary(norway$Bottom)
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# -1.010   7.433   8.145   8.037   9.000  12.260 


# Golden redfish
golden = read.csv("golden.csv")
summary(golden)
quantile(golden$Bottom, c(0.10))
mean(golden$Bottom)
quantile(golden$Bottom, c(0.90))
summary(golden$Bottom)
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# -1.010   2.640   3.220   4.022   4.662  14.880 


# Beaked redfish
beaked = read.csv("beaked.csv")
summary(beaked)
quantile(beaked$Bottom, c(0.10))
mean(beaked$Bottom)
quantile(beaked$Bottom, c(0.90))
summary(beaked$Bottom)
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# -1.250   1.695   2.940   3.080   3.525  12.410 


# Capelin
capelin = read.csv("capelin.csv")
summary(capelin)
quantile(capelin$Bottom, c(0.10))
mean(capelin$Bottom)
quantile(capelin$Bottom, c(0.90))
summary(capelin$Bottom)
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# -1.250   1.778   3.330   3.659   5.390  13.010


#Daubed shanny
shanny = read.csv("shanny.csv")
summary(shanny)
quantile(shanny$Bottom, c(0.10))
mean(shanny$Bottom)
quantile(shanny$Bottom, c(0.90))
summary(shanny$Bottom)
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#  -1.33    0.92    2.91    3.30    5.29   12.26 


#Polar cod
polar = read.csv("polar.csv")
summary(polar)
quantile(polar$Bottom, c(0.10))
mean(polar$Bottom)
quantile(polar$Bottom, c(0.90))
summary(polar$Bottom)
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#-1.5200 -0.4800  0.6200  0.9298  2.0900  8.2300 

